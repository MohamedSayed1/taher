<blockquote class="instagram-media" data-instgrm-captioned
    data-instgrm-permalink="https://www.instagram.com/reel/{{ $video_link_id }}/?utm_source=ig_embed&amp;utm_campaign=loading"
    data-instgrm-version="14"
    style=" background:#FFF; border:0; border-radius:3px; box-shadow:0 0 1px 0 #1ba9ff,0 1px 10px 0 #1ba9ff; margin: 1px; max-width:540px; min-width:326px; padding:0; width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);">
</blockquote>
<script async src="//www.instagram.com/embed.js"></script>
<style>
    .instagram-media {
        max-width: 100% !important;
    }

    @media (max-width: 414px) {
        #play-video-content iframe {
            height: 1000px !important;
        }
    }

    @media (max-width: 820px) {
        #play-video-content iframe {
            height: 1000px !important;
        }
    }
</style>

<?php

return [
    'Permissions' => 'Permissions',
    'View Moderatores' => 'View Moderatores',
    'Create Moderator' => 'Create Moderator',
    'Update Moderator' => 'Update Moderator',
    'Delete Moderator' => 'Delete Moderator',
    'View Roles' => 'View Roles',
    'Create Role' => 'Create Role',
    'Update Role' => 'Update Role',
    'Delete Role' => 'Delete Role',
];
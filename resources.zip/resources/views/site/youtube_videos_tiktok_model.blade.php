<blockquote class="tiktok-embed" data-video-id="{{ $video_link_id }}" style="max-width: 605px;min-width: 325px;">
    <section></section>
</blockquote>
<script async src="https://www.tiktok.com/embed.js"></script>

<style>
    .tiktok-embed {
        max-width: 100% !important;
    }

    .tiktok-embed iframe {
        width: 100% !important;
    }
</style>

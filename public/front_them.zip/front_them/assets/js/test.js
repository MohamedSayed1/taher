//import './speech.js';

// Increase Font
$(document).on('click', '.increase-font', function() {
    $(".data-wrapper").css('font-size', '22px')
});
$(document).on('click', '.decrease-font', function() {
    $(".data-wrapper").css('font-size', '18px')
});